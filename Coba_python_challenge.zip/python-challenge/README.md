# python-challenge
This is my homework results for PyPoll and PyBank. If you click on each folder you will see a text
file and the main.py file which is unique for each dataset. 
